function getTeam(){return 'default';}
function loadVideos(){
  const team=getTeam();
  const list=JSON.parse(localStorage.getItem(`videos_${team}`)||'[]');
  renderVideos(list);
}
function renderVideos(list){
  const el=document.getElementById('videoList');
  el.innerHTML='';
  list.forEach(v=>{
    const d=document.createElement('div');
    d.textContent=v.id;
    el.appendChild(d);
  });
}
function addVideo(){
  const url=document.getElementById('youtubeUrl').value.trim();
  const m=url.match(/(?:youtu\.be\/|youtube\.com\/.*v=)([^&]+)/);
  if(!m){alert('URL error');return;}
  const id=m[1];
  const team=getTeam();
  let list=JSON.parse(localStorage.getItem(`videos_${team}`)||'[]');
  list.push({id});
  localStorage.setItem(`videos_${team}`,JSON.stringify(list));
  loadVideos();
}
